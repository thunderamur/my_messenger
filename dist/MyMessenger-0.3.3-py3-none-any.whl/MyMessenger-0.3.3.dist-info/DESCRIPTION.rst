Study project of chat based on JSON IM protocol with python3 and PyQt5


